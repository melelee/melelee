CREATE FUNCTION midc_dev.getChild(rootId INT)
  RETURNS VARCHAR(1000)
  BEGIN
        DECLARE ptemp VARCHAR(1000);
        DECLARE ctemp VARCHAR(1000);
               SET ptemp = '#';
               SET ctemp =CAST(rootId AS CHAR);
               WHILE ctemp IS NOT NULL DO
                 SET ptemp = CONCAT(ptemp,',',ctemp);
                SELECT GROUP_CONCAT(id) INTO ctemp FROM tb_system_dict   
                WHERE FIND_IN_SET(PARENT_ID,ctemp)>0; 
               END WHILE;  
               RETURN ptemp;  
END;
