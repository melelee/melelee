CREATE FUNCTION saas_web0301.currval(v_seq_name VARCHAR(50))
  RETURNS INT
  begin declare value integer; set value = 0; select current_val into value from tb_sequence where seq_name = v_seq_name; return value; end;
