CREATE VIEW v_abk_bianditwandplw AS
  SELECT
    `a`.`id`           AS `taskid`,
    `a`.`tasktitle`    AS `taskname`,
    `a`.`baseintegral` AS `baseintegral`,
    `b`.`jfqz`         AS `priorleveweight`,
    `c`.`JFQZ`         AS `imageweight`
  FROM `abk`.`t_abk_taskbaseinstegral` `a`
    JOIN `abk`.`t_abk_yxj` `b`
    JOIN `abk`.`t_abk_yxlx` `c`
  WHERE ((`a`.`imagetypeid` = `b`.`id`) AND (`a`.`priorleveid` = `c`.`id`));
