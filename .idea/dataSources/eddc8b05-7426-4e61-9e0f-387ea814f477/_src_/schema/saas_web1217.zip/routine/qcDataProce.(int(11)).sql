CREATE PROCEDURE saas_web1217.qcDataProce(IN param1 INT)
  BEGIN   
	DECLARE patientName VARCHAR(50); 
	DECLARE bussinessId VARCHAR(100); 
	DECLARE hospitalCode VARCHAR(100);
	DECLARE hospitalCity VARCHAR(100);
	DECLARE locationCode VARCHAR(100);
	DECLARE dataType VARCHAR(100);
	DECLARE studyDate VARCHAR(100);
	DECLARE studyDateQc VARCHAR(100);
	DECLARE studyTime VARCHAR(100);
	DECLARE studyType VARCHAR(100);
	DECLARE accessionNum VARCHAR(100);
	DECLARE handleProcess VARCHAR(20);
	DECLARE i INT DEFAULT 0;
	DECLARE randValue DOUBLE;
  loop_label: LOOP
		SET randValue = RAND();
		IF(randValue > 0.5) THEN
			SELECT HOSPITAL_CODE,HOSPITAL_CITY,LOCATION_CODE,DATA_TYPE INTO hospitalCode,hospitalCity,locationCode,dataType FROM tb_hospital_dictionary
			WHERE DISPLAY = 1 AND WEIGHT = 1 AND HOSPITAL_CODE LIKE '%' ORDER BY rand() LIMIT 1;
		ELSEIF(randValue <= 0.5 AND randValue > 0.2) THEN
			SELECT HOSPITAL_CODE,HOSPITAL_CITY,LOCATION_CODE,DATA_TYPE INTO hospitalCode,hospitalCity,locationCode,dataType FROM tb_hospital_dictionary
			WHERE DISPLAY = 1 AND WEIGHT = 1 AND HOSPITAL_CODE LIKE '%' ORDER BY rand() LIMIT 1;
		ELSEIF(randValue <= 0.2 AND randValue > 0.1) THEN
			SELECT HOSPITAL_CODE,HOSPITAL_CITY,LOCATION_CODE,DATA_TYPE INTO hospitalCode,hospitalCity,locationCode,dataType FROM tb_hospital_dictionary
			WHERE DISPLAY = 1 AND WEIGHT = 1 AND HOSPITAL_CODE LIKE '%' ORDER BY rand() LIMIT 1;
		ELSE
			SELECT HOSPITAL_CODE,HOSPITAL_CITY,LOCATION_CODE,DATA_TYPE INTO hospitalCode,hospitalCity,locationCode,dataType FROM tb_hospital_dictionary
			WHERE DISPLAY = 1 AND WEIGHT = 1 AND HOSPITAL_CODE LIKE '%' ORDER BY rand() LIMIT 1;
		END IF;
		SELECT nextval('seq_test1_num1') INTO bussinessId;
		SET accessionNum = bussinessId;
		SET patientName = getRandomName();
		SET studyDate = DATE_FORMAT(NOW(),'%Y%m%d');
		SET studyDateQc = DATE_FORMAT(NOW(),'%Y-%m-%d');
		SET studyTime = DATE_FORMAT(NOW(),'%H%I%S');
		IF (dataType = 'CT') THEN
			SET studyType = 'CT';
		ELSEIF (dataType = 'DR') THEN
			SET studyType = 'DR';
		ELSE
			SET studyType = 'MG';
		END IF;
		IF (randValue>0.15) THEN
			SET handleProcess = '1';
		ELSEIF(randValue>0.05 AND randValue<= 0.15) THEN
			SET handleProcess = '2';
		ELSE 
			SET handleProcess = '3';
		END IF;
		INSERT INTO tb_apply_consultation_copy(ID,BUSSINESS_ID,APPLY_HOSPITAL,APPLY_HOSPITAL_LOCATION,CONSULT_WAY,DCM_TRANS_WAY,HANDLE_PROCESS) 
		VALUES (bussinessId,bussinessId,hospitalCode,locationCode,'AI','FTP','2');
		INSERT tb_consult_study_info_copy(APPLY_ID,ACCESSION_NUM,PATIENT_ID,PATIENT_NAME,STUDY_DATE,STUDY_TIME,STUDY_TYPE) 
		VALUES(bussinessId,accessionNum,bussinessId,patientName,studyDate,studyTime,studyType);
		INSERT INTO tb_qc_info_copy(APPLY_ID,USER_ID,CHK_ID,REPORT_CONTENT,AI_RESULT,HANDLE_PROCESS,STUDY_DATE,PATIENT_ID,PATIENT_NAME,
		PATIENT_TYPE,CHK_STATE,LOCATION_CODE,HOSPITAL_CODE,UPDATE_TIME) 
		VALUES(bussinessId,'ct001',accessionNum,'未见明显异常',4,handleProcess,studyDateQc,bussinessId,patientName,'门诊病人','已录入报告',locationCode,hospitalCode,NOW());
		SET i = i + 1;
	    IF i >= param1 THEN
		LEAVE loop_label;
		END IF;
  END LOOP; 
END;
